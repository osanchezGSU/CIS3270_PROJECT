package Common;

public class Admin {
	

}
