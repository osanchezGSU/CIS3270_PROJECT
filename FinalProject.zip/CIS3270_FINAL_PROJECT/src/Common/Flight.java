package Common;

public class Flight {

}
