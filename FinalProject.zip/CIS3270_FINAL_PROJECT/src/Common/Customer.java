package Common;

public class Customer {

}
